# UI patterns for compact boards

Contents: 1. Principles - 2. Layout skeleton - 3. Uniform controls - 4. Filter row - 5. Version capsule and versions menu - 6. Menus that survive the host - 7. Project picker and form - 8. Archive, restore, delete - 9. Spacing method - 10. Theme and background - 11. RTL and Hebrew - 12. Research sources

## 1. Principles (each one came from user feedback)

- Everything for the main task on as few lines as possible; no scrolling for controls. Users asked repeatedly to merge rows and shrink controls.
- One format per row. Same height, radius, font and size for dropdowns, search, buttons and toggles. Inconsistent shapes were called out as "not uniform".
- Labels visible next to icons and before groups ("Show:", "Filter:"). Icons alone are ambiguous.
- A dropdown that is not a filter does not belong among the filters (an identity picker in the filter row was read as a broken filter). Move such settings to a technical tab.
- Remove what duplicates something else (stat cards that repeat filter counts, type tags that repeat the type dropdown).
- Spacing: gentle. A full-width `space-between` spread was rejected immediately ("too much space"). Change by a few pixels and report numbers.
- Red only for destructive actions (delete). The primary action is the single filled button.

## 2. Layout skeleton

```
[logo][title "Tasks of <project>"] [chips: in development X | released Y] [version capsule] [project picker] ........ [search][+ New task][List|Columns]
[Show:] [tab][tab][tab][tab] | [funnel Filter:] [Type v][Status v][Sort v][Owner v][Severity v][Package v][Source v] [x clear]
[columns: To do | In progress | For review | Done]  (each column scrolls inside itself, cards keep their size)
```

- The top line lives in a "side" frame whose children use `display:contents` and `order` so markup order can stay semantic.
- On desktop the two frames join with no gap at full width; on the phone they become two tabs and the search/actions move back next to the task tabs (a `matchMedia('(min-width:961px)')` listener moves the DOM nodes; event listeners move with them).
- Cards: one-line title with ellipsis, small pills (type, severity, owner, status), no progress bars.

## 3. Uniform controls

```css
.fdd,.pp-btn,#view,.tasks-actions .create,.tasks-actions input[type=search]{box-sizing:border-box!important;height:30px;border-radius:8px;font-family:var(--text);font-size:.8rem}
.fdd{display:inline-flex;align-items:center;border:1px solid var(--line);background:var(--paper)}
.fdd-k{color:var(--ink-soft);padding-inline:8px 3px}                 /* the label inside: "Type" */
.fdd select{appearance:none;border:0;background:transparent;font-weight:700;field-sizing:content;max-width:9.5em;padding-left:21px}
.fdd::after{content:"";position:absolute;left:8px;top:50%;width:8px;height:5px;margin-top:-2px;background:var(--ink-soft);clip-path:polygon(0 0,100% 0,50% 100%);pointer-events:none}
.fdd.on{border-color:var(--chef-deep);background:color-mix(in srgb,var(--chef) 16%,var(--paper))}   /* changed from default */
#view{display:inline-flex;border:1px solid var(--line);overflow:hidden}                             /* segmented toggle */
#view .opt[aria-pressed="true"]{background:color-mix(in srgb,var(--chef) 16%,var(--paper));color:var(--chef-deep)}
```

- `box-sizing:border-box` matters: without it a 30px control with a 1px border measures 32px next to 30px ones (a test caught exactly that).
- `field-sizing:content` sizes a select to its current value (Chromium; older browsers fall back to the widest option, still usable).
- Search: placeholder "Search" with a magnifier icon, full hint in `title`. Width 110-160px on 1280-1600, up to 210px on 1700+. Research suggests 27 characters, but this user preferred smaller; follow the user.

## 4. Filter row

- Native `<select>` elements wrapped in labels: accessible, keyboard friendly, no custom popover bugs.
- Build the options once at init. Data refreshes only set `.value` (and only if it differs) and toggle `.on`. Rebuilding options closes an open native dropdown under the user's mouse.
- "x clear" appears only when something differs from the defaults; it resets filters, sort and extra filters.
- Default status depends on the view (columns: all; list: open).
- Stat cards (open / blockers / late / for review / waiting / done) were removed at the user's request. If you remove such cards, say which shortcuts disappear (blockers, overdue) and offer them as options elsewhere.

## 5. Version capsule and versions menu

One rounded element: `[Version 1.2 v][status chip][target date][build][3/14 done][21%][gear][+][archive][trash]`, the progress shown as a fill behind the capsule (`--p:21%`).

- `v` opens the versions menu: one row per version with status and done/total plus a mini bar, "No version", an "Archived" section, and "+ New version".
- `+` opens the new-version form (name prefilled with the next number, "add template tasks" checkbox). The form state lives in a variable (`newRel`) so a data refresh re-renders it instead of erasing it.
- The gear opens the manage panel (target date, status, release flow, copy "what's new", delete).
- Archive: saves `status:'archived'` and `prevStatus`, switches to another version. Opening an archived version shows the same button highlighted as "restore", which puts `prevStatus` back. Without an "Archived" section in the menu an archived version is unreachable.
- Trash: opens the manage panel and the existing delete confirmation (move tasks to "No version" or delete them too). Hover turns it red.
- Exports and backups must include archived versions.

## 6. Menus that survive the host

The board runs inside claude.ai in an iframe whose size changes as the mouse moves (toolbars appear and hide). A menu that closes on `resize` vanishes the moment the user reaches for its button.

```js
window.addEventListener('resize',placeVerMenu);           // reposition, do not close
function renderRelPanel(){var reopen=!!$('vb-menu');renderRelPanel0();
  if(reopen&&!$('vb-menu')){var pk=document.querySelector('#relpanel .vb-pick');if(pk)toggleVerMenu(pk,true)}}  // redraw keeps it open, without stealing focus
```

- Append floating menus to `body` with `position:fixed`; compute top/left from the trigger's rect; clamp to the viewport.
- Close on outside click and Escape; arrow keys move focus.
- Test it by dispatching `resize` while moving the mouse, and by firing a data snapshot while it is open (see testing.md, the iframe repro).

## 7. Project picker and form

- A button in the top line: `[icon] Project GC v`, same format as the dropdowns; the label word hides below 1440px.
- Menu: each project with icon, name, symbol and task count; "+ New project"; "Edit project".
- Form (modal dialog, Escape and backdrop close): name (used in the title), symbol (2-5 latin letters/digits, starts with a letter, forced to upper case, unique, locked after creation), optional image (resized to 96px), live preview of the generated icon.

## 7b. Expanded card: actions and closing

- Actions in one centered grid of equal buttons (34px, 8px radius): "x Close", "Attach files", "Archive", "Delete" (delete last, red outline, two-step confirm). `grid-template-columns:repeat(auto-fit,minmax(104px,1fr)); max-width:624px; margin-inline:auto` gives 4 in a row on wide cards, 2x2 on narrow columns and phones.
- Closing (W3C APG disclosure pattern and common card guidance): a labelled close button (`aria-label="Close card GC-7"`), Escape, clicking the title again, and clicking anywhere outside the open card. Return focus to the card's summary. Clicks on inner controls never close it; menus and dialogs take Escape first.
- One open card at a time keeps the board readable and makes "click outside closes" predictable. Highlight the open card with a soft ring.

## 7c. Card fields and the floating card window

- Expanded card fields render as bold-labelled sub-sections (description, screen, device, file, source, note, files, dates). An empty field renders nothing, not even its label. Long text keeps line breaks (`white-space:pre-line`); the note gets a highlighted box; short fields sit in a two-column label/value grid.
- A small expand icon in every card title opens the card in a floating window (modal). If the card is open on the board it closes there first; closing the window never reopens it.
- Modal standard (W3C APG dialog-modal, MDN aria-modal): `role=dialog`, `aria-modal`, `aria-labelledby` the title; everything else `inert`; initial focus on the title (content-heavy dialog); Escape, the close button and a click anywhere on the backdrop close it, but only when the press also started on the backdrop (a drag-select ending outside does not close it); focus returns to the icon; body scroll locked; near full screen on phones.
- Closing blurs a focused field first so its change event saves the text. Live updates re-render the window except while someone types in it (deferred until focus leaves). Inside the window the card's ids get an `fl-` prefix (no duplicate ids with the board card).

## 7d. Screenshots and files in a card

Images in an expanded card or the floating window: previews 240px tall (200px under 600px wide), `width:auto; max-width:100%; object-fit:contain`, the file name without its extension under each, `loading=lazy`. Closed cards show only a count pill ("2 קבצים").

**Never a link that opens a new tab.** Inside claude.ai a `target=_blank` link (or `window.open`) to `/_blob/<id>` shows "this link cannot be opened here". Each image tile is a `<button>` that opens an in-page viewer; other files are buttons that download through the `downloads` capability (`fetch('/_blob/'+id)` then `downloads.save({filename, data: blob})`, toast on decline or failure).

In-page image viewer (lightbox), per the W3C APG modal dialog pattern: `role=dialog`, `aria-modal`, `aria-label` = image name; everything else `inert`; focus on the close button when it opens and back on the tile when it closes (re-found by file id if the card re-rendered); Escape, the close button, or a click outside the image close it (only if the press also started outside, so a drag from the image does not); arrow keys and "→ הקודמת" / "הבאה ←" buttons move between the card's images and wrap; "1 מתוך 2" counter; a download button. The close button has its own row above the image so it never covers it; the image is limited to `100dvh - 176px`. The Escape listener is on `window` in the capture phase and stops propagation, so when the viewer was opened from the floating window, the first Escape closes only the viewer. Tests 48d-48j.

## 7e. Sync warning (connection to the database)

Two levels, so nobody misses a real problem and nobody gets a false alarm:
- **Quiet:** a gold ring on the logo and a status line once no confirmed data arrived within 12 seconds (slow start). No popup.
- **Loud:** after a full minute of *visible* time without confirmed data (tab hidden time does not count), a persistent banner fixed at the bottom center, `role="alert"` on a container that exists from page load, yellow with a dark text and a strong start border, dark-mode colors. Text: what is wrong in one line ("הלוח לא מתעדכן מהמאגר כבר יותר מדקה"), the time of the copy shown (viewer's local time), what to do (do not edit, refresh, send diagnostics if it returns). Buttons: "פרטים טכניים" (opens the diagnostics tab with the send button focused) and "הבנתי" (hides it until the problem ends and a new one starts). It hides itself on the first confirmed snapshot and a toast says the connection is back.

Not a modal: the board stays readable and usable while waiting (web.dev offline UX guidelines; SAP Fiori offline banner). Quiet time is not an error: once confirmed, the board is "fresh" until a subscription actually fails, so ten minutes with nobody editing never shows anything (board tests 51a-h). Limit: a listener that silently stops without an error cannot be detected by the page.

## 8. Archive, restore, delete (general rule)

Any action that hides data needs a visible way back, and any action that removes data needs a confirmation that says what happens to dependent data. Archive is one click and reversible; delete is two steps.

## 9. Spacing method

1. Measure first (`measure_layout.js`): gaps between groups, leftover space, row line count, at 1280/1440/1600/1920.
2. Distribute leftover with capped spacers instead of `space-between`:
   ```css
   .tsp{flex:1 1 0;min-width:0;max-width:26px;height:1px;margin-inline:-5px}   /* with column-gap:10px => gap grows 10..36px */
   ```
   Place spacers with `order` between groups; keep logo and title glued.
3. Check the narrowest desktop width still fits on one line; add a smaller variant for 961-1340px rather than letting the row wrap.
4. Report before/after numbers per width.

## 10. Theme and background

- Light: page `#F3F4F1`, surfaces `#FFFFFF`, columns `#ECEEEA`, lines `#DCE1DB`, text `#1E2A25`, soft text `#56635D`.
- Dark: page `#121513`, surfaces `#1C211E`, columns `#171B19`, lines `#2E3732`, text `#E2E8E4`, soft text `#9AA8A1`.
- Optional faint geometric SVG tile (circles, rounded squares, triangles, plus, wave) at 8-13% stroke opacity, separate tints for dark mode, as `background-image` on the page and columns.
- Primary button text uses `var(--paper)` so it stays readable when the brand color turns light in dark mode (measured 9:1 light, 10.6:1 dark).
- Define tokens on `:root`, redefine under `prefers-color-scheme: dark` guarded by `:root:not([data-theme="light"])` and under `:root[data-theme="dark"]`.

## 11. RTL and Hebrew

- `dir="rtl"` on the page; use logical properties (`margin-inline-start`, `padding-inline`, `border-inline-start`) so the layout mirrors correctly.
- `position:absolute; left:8px` for a select's chevron is intentional in RTL (the chevron sits at the end of the text).
- Keys and symbols (`GC-17`, `APP`) get `dir="ltr"` inputs.
- Test with real Hebrew strings; Hebrew words are shorter in pixels than English but labels get longer.

## 12. Research sources used

- Nielsen Norman Group, icon usability (labels next to icons): https://www.nngroup.com/articles/icon-usability/
- Nielsen Norman Group, search box width (27 characters): https://www.nngroup.com/articles/magnifying-glass-icon/
- Baymard Institute, applied filters: https://baymard.com/blog/how-to-design-applied-filters
- Maersk design system, filter patterns: https://designsystem.maersk.com/guidelines/search-filter-and-sort/filter-patterns/
- Genesys Spark, table filtering (inline dropdowns for few filters): https://spark.genesys.com/latest/patterns/table-filtering/overview-QwBXFv4E
- PatternFly filter guidelines: https://v4-archive.patternfly.org/v4/design-guidelines/usage-and-behavior/filters
- Background colors: Atlassian elevation https://atlassian.design/foundations/elevation, Material dark theme https://m2.material.io/design/color/dark-theme
